# Identifikasi Serangga > 2025-02-04 5:42pm
https://universe.roboflow.com/object-detection-nvmtf/identifikasi-serangga

Provided by a Roboflow user
License: CC BY 4.0

